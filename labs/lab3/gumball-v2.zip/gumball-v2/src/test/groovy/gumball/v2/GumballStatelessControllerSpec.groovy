package gumball.v2

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GumballStatelessControllerSpec extends Specification implements ControllerUnitTest<GumballStatelessController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
