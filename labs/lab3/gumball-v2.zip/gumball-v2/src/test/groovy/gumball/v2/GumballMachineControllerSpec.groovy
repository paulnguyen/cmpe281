package gumball.v2

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GumballMachineControllerSpec extends Specification implements ControllerUnitTest<GumballMachineController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
