package gumball.v2

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GumballSecuredControllerSpec extends Specification implements ControllerUnitTest<GumballSecuredController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
