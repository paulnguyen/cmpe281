package gumball.v2

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
