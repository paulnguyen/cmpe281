package gumball.v3

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
