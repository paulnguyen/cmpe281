package gumball.v3

class GumballOrder {

	String	orderstatus ;
	
	static mapping = {
		id generator: 'increment'
	}
 
}
