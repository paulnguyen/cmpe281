package gumball.v1

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
