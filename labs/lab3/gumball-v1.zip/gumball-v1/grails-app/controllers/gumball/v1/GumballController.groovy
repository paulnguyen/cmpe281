package gumball.v1

class GumballController {

     static scaffold = Gumball 

}
