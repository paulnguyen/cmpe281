package gumball.v1

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GumballControllerSpec extends Specification implements ControllerUnitTest<GumballController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
