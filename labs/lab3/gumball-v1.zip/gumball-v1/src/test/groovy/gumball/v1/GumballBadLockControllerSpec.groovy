package gumball.v1

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class GumballBadLockControllerSpec extends Specification implements ControllerUnitTest<GumballBadLockController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
