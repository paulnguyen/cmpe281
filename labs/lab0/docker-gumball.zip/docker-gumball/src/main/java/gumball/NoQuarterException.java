
package gumball ;  


/**
 * Write a description of class NoQuarterException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NoQuarterException extends GumballException
{

}
