
package gumball ;  

public class HasQuarterException extends GumballException
{
    
}
